#!/bin/bash

/usr/bin/uptime > /home/deep/uptime.log
